﻿namespace WinApplWatcher {
    
    
    public partial class ProcessDiscoveryDBDataSet {
    }
}
namespace WinApplWatcher {
    
    
    public partial class ProcessDiscoveryDBDataSet {
    }
}
